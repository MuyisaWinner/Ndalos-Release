@echo off
echo Nettoyage du reseau en cours...
ipconfig /flushdns
ipconfig /release
ipconfig /renew
echo Le cache DNS et l'IP ont ete réinitialises !
pause